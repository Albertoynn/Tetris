#ifndef __TOOLS_AND_TYPDEF__
#define __TOOLS_AND_TYPDEF__

typedef unsigned int bool;
#define true  1
#define false 0

#define nullptr ((void *)0)

#define test_mod false

#endif // __TOOLS_AND_TYPDEF__
