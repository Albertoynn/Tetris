#ifndef __TEST_BOARD__
#define __TEST_BOARD__

void test_all_board();

#endif // __TEST_BOARD__
